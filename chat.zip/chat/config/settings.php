<?php
define('URL', 'http://localhost/chat/');
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'chat');
define('DB_PORT', '3306');
define('DB_PREFIX', 'cn_');
?>
